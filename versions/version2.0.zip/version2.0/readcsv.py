import csv
import webbrowser

# with open('temp-and-humidity/sensor-values/humidity_temp&humi_latest_value.csv') as csvfile:
with open('static/humidity_temp&humi_latest_value.csv') as csvfile: 
    readCSV = csv.reader(csvfile, delimiter=',')
    dates = []
    values = []
    for row in readCSV:
        value = row[1]
        date = row[0]

        dates.append(date)
        values.append(value)
        
        
    #print(dates[0])
    humi = values[1]
    print(humi)
    if float(humi) > 85:
      print("Humidity too high")
      webbrowser.open('http://100.67.26.5:8080/6/off')
    else:
      webbrowser.open('http://100.67.26.5:8080/6/on')
    # now, remember our lists?
# 
#     whatColor = input('What value do you wish to know the date of?:')
#     coldex = colors.index(whatColor)
#     theDate = dates[coldex]
#     print('The date of',whatColor,'is:',theDate)