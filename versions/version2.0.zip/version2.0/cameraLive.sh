#!/bin/bash

raspistill -o /home/pi/Desktop/ProjEnv/static/camera/pic.jpg