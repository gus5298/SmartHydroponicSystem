#!/bin/bash

DATE=$(date +"%Y-%m-%d_%H%M")

raspistill -o /home/pi/Desktop/ProjEnv/static/camera/$DATE.jpg