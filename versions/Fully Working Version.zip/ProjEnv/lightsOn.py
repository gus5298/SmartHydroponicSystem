import webbrowser
import subprocess

#turns the lights ON
webbrowser.open('http://100.67.26.5:8080/26/on')
cmd = "pkill -o chromium"
subprocess.call(cmd, shell=True)
