#!/bin/bash
#takes picture and stores it, this is called every 60 minutes using crontab

DATE=$(date +"%Y-%m-%d_%H%M")

raspistill -o /home/pi/Desktop/ProjEnv/static/camera/$DATE.jpg