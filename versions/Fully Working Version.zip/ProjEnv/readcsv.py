import csv
import webbrowser
import subprocess

# read CSV values
with open('/home/pi/Desktop/ProjEnv/static/humidity_temp&humi_latest_value.csv') as csvfile: 
    readCSV = csv.reader(csvfile, delimiter=',')
    dates = []
    values = []
    for row in readCSV:
        value = row[1]
        date = row[0]

        dates.append(date)
        values.append(value)
        
        
    
    humi = values[1]
    
#turn the fan ON if the humididty is over 80% and turn it OFF if it is below 80%
    if float(humi) > 80:

      webbrowser.open('http://100.67.26.5:8080/6/on')
      cmd = "pkill -o chromium"
      subprocess.call(cmd, shell=True)
    else:
      webbrowser.open('http://100.67.26.5:8080/6/off')
      cmd = "pkill -o chromium"
      subprocess.call(cmd, shell=True)