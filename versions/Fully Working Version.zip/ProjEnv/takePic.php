<?php
shell_exec("cameraLive.sh");
header('Location: /');
?>
