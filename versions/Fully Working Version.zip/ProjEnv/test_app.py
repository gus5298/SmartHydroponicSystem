# test_app.py 
from app import app
#testing every endpoint in the system:
def test_homepage():
    response = app.test_client().get('/')

    assert response.status_code == 200
    
def test_pumpOn():    
    response = app.test_client().get('/16/on')

    assert response.status_code == 200
    
def test_pumpOff():    
    response = app.test_client().get('/16/off')

    assert response.status_code == 200
    
def test_fanOn():    
    response = app.test_client().get('/6/on')

    assert response.status_code == 200

def test_fanOff():    
    response = app.test_client().get('/6/off')

    assert response.status_code == 200
def test_LightsOn():    
    response = app.test_client().get('/26/on')

    assert response.status_code == 200

def test_LightsOff():    
    response = app.test_client().get('/26/off')

    assert response.status_code == 200
    
def test_takePic():    
    response = app.test_client().get('/pic')

    assert response.status_code == 200

def test_pageNotFound():    
    response = app.test_client().get('/notExisting')

    assert response.status_code == 404 