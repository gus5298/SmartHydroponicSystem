#!/bin/bash
#takes picture and stores it, this is called every 5 minutes using crontab
raspistill -o /home/pi/Desktop/ProjEnv/static/camera/pic.jpg
