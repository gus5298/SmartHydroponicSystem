import webbrowser
import subprocess

#turns the lights OFF
webbrowser.open('http://100.67.26.5:8080/26/off')
cmd = "pkill -o chromium"
subprocess.call(cmd, shell=True)
