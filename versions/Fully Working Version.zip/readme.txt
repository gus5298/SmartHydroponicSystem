###################################################
Smart Hydroponic Growing System using IoT
###################################################
by Gustavo Sanchez Collado
Supervisor: Michael Bass
###################################################

- The work is located inside 'ProjEnv' (Project Environment).

- The 'crontab.txt' is the local file used to configure cron jobs (see section 3.3.4 of the report).

- The 'Dropbox-Uploader' folder contains the code that backups files to Dropbox (see section 3.3.5 and 5.4.7 of the report).