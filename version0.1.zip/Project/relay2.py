
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
import RPi.GPIO as GPIO
import time
 
relay_pin = 26
 
GPIO.setmode(GPIO.BCM)
GPIO.setup(relay_pin,GPIO.OUT)
 
try:
        while True:
                #set low
                print ("Setting low - LED ON")
                GPIO.output (relay_pin,GPIO.HIGH)
                time.sleep(2)
                #set high
                print ("Setting high - LED OFF")
                GPIO.output (relay_pin, GPIO.LOW)
                time.sleep(2)
except KeyboardInterrupt:
        GPIO.cleanup()
        print ("Bye")